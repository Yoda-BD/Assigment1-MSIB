package com.example.myapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private Button saveButton;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        saveButton = findViewById(R.id.saveButton);

        sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);

        // Restore the saved string if available
        String savedString = sharedPreferences.getString("userString", "");
        editText.setText(savedString);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the user input
                String inputString = editText.getText().toString();

                // Save the input string in SharedPreferences
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("userString", inputString);
                editor.apply();
            }
        });
    }
}